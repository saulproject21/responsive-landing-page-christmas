# Responsive Landing Page Christmas
## [Watch it on youtube](https://youtu.be/RTIueV7zERY)
### Responsive Landing Page Christmas
Beautiful Christmas Responsive Landing Page 🎄. Contains a Header, Home Section, Share, Decorations, Accessories, Send Gift, and Footer. It also has a fully developed light / dark mode 🌓 first for mobile devices and then for desktop computers.
[Bedimcode](https://www.youtube.com/c/Bedimcode)
